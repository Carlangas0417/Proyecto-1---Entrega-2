package learningpaths;

import java.util.ArrayList;
import java.util.List;

public class Estudiante extends Usuario {
    private List<String> intereses;
    private float progreso;
    private List<Reseña> reseñas;

    // Constructor
    public Estudiante(int id, String nombre, String correo, String contraseña, List<String> intereses) {
        super(id, nombre, correo, contraseña);
        this.intereses = intereses;
        this.progreso = 0.0f; // Progreso inicial en 0%
        this.reseñas = new ArrayList<>();
    }

    // Métodos getter y setter
    public List<String> getIntereses() {
        return intereses;
    }

    public void setIntereses(List<String> intereses) {
        this.intereses = intereses;
    }

    public float getProgreso() {
        return progreso;
    }

    // Ver rutas de aprendizaje disponibles (placeholder para futuras implementaciones)
    public List<RutaAprendizaje> verRutasAprendizaje() {
        // Lógica para obtener las rutas de aprendizaje disponibles
        return new ArrayList<>(); // Placeholder, se conectará con la clase RutaAprendizaje
    }

    // Iniciar una actividad
    public void iniciarActividad(Actividad actividad) {
        if (actividad.verificarPrerrequisitos(this)) {
            System.out.println("Iniciando actividad: " + actividad.getTitulo());
            actividad.completar(this);
            calcularProgreso();
        } else {
            System.out.println("Advertencia: No se han cumplido todos los prerrequisitos para esta actividad.");
            // Opción para que el estudiante decida continuar o no
            // En un sistema real, aquí podríamos tener lógica para aceptar o rechazar continuar
        }
    }

    // Completar una actividad
    public void completarActividad(Actividad actividad) {
        actividad.completar(this);
        calcularProgreso();
    }

    // Calcular el progreso del estudiante en base a las actividades completadas
    private void calcularProgreso() {
        // Lógica para calcular el progreso basado en las actividades completadas
        // Este es un simple placeholder para demostración
        this.progreso += 10.0f; // Incremento de progreso por cada actividad (simulación)
        System.out.println("Progreso actual: " + this.progreso + "%");
    }

    // Dejar una reseña en una actividad
    public void dejarReseña(Actividad actividad, int calificacion, String comentario) {
        Reseña reseña = new Reseña(calificacion, comentario);
        reseñas.add(reseña);
        actividad.agregarReseña(reseña); // Método hipotético en Actividad para añadir la reseña
        System.out.println("Reseña añadida a la actividad: " + actividad.getTitulo());
    }
}
