package learningpaths;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class TestLearningPaths {
    public static void main(String[] args) {
        // Crear un profesor
        Profesor profesor = new Profesor(1, "Carlos", "carlos@learning.com", "password123", "Programación");

        // Crear un estudiante
        List<String> intereses = new ArrayList<>();
        intereses.add("Programación");
        intereses.add("Matemáticas");
        Estudiante estudiante = new Estudiante(2, "David", "david@learning.com", "password123", intereses);

        // Crear una ruta de aprendizaje
        RutaAprendizaje ruta = new RutaAprendizaje(1, "Java Básico", "Introducción a Java", "Principiante", 120, "1.0");
        profesor.crearRutaAprendizaje(ruta);

        // Crear actividades y agregarlas a la ruta
        Actividad actividad1 = new Actividad(1, "Instalación de JDK", "Guía para instalar JDK y configurar el entorno", "Clase", "Principiante", 30, new Date());
        Actividad actividad2 = new Actividad(2, "Hola Mundo en Java", "Escribir y ejecutar tu primer programa en Java", "Tarea", "Principiante", 45, new Date());
        Actividad actividad3 = new Actividad(3, "Conceptos básicos", "Aprender variables y tipos de datos en Java", "Clase", "Principiante", 45, new Date());

        ruta.agregarActividad(actividad1);
        ruta.agregarActividad(actividad2);
        ruta.agregarActividad(actividad3);

        // Simular al estudiante iniciando y completando actividades
        System.out.println("\nEstudiante inicia la primera actividad:");
        estudiante.iniciarActividad(actividad1);

        System.out.println("\nEstudiante inicia la segunda actividad:");
        estudiante.iniciarActividad(actividad2);

        System.out.println("\nEstudiante inicia la tercera actividad:");
        estudiante.iniciarActividad(actividad3);

        // Verificar el progreso del estudiante
        System.out.println("\nVerificando progreso del estudiante en la ruta:");
        ruta.calcularProgreso(estudiante);

        // Estudiante deja una reseña en la primera actividad
        System.out.println("\nEstudiante deja una reseña en la primera actividad:");
        estudiante.dejarReseña(actividad1, 5, "Muy clara la explicación.");

        // Profesor revisa las reseñas de la primera actividad
        System.out.println("\nProfesor revisa las reseñas de la primera actividad:");
        List<Reseña> reseñas = profesor.verReseñas(actividad1);
        for (Reseña reseña : reseñas) {
            System.out.println("Calificación: " + reseña.getCalificacion() + ", Comentario: " + reseña.getComentario());
        }
    }
}
