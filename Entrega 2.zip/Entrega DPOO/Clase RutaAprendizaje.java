package learningpaths;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RutaAprendizaje {
    private int id;
    private String titulo;
    private String descripcion;
    private String nivel; // e.g., "Principiante", "Intermedio", "Avanzado"
    private int duracion; // Duración total en minutos
    private float calificacion; // Calificación promedio basada en reseñas
    private Date fechaCreacion;
    private Date fechaModificacion;
    private String version;
    private List<Actividad> actividades;

    // Constructor
    public RutaAprendizaje(int id, String titulo, String descripcion, String nivel, int duracion, String version) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.nivel = nivel;
        this.duracion = duracion;
        this.version = version;
        this.fechaCreacion = new Date();
        this.fechaModificacion = new Date();
        this.actividades = new ArrayList<>();
        this.calificacion = 0.0f; // Inicialmente, la ruta no tiene calificación
    }

    // Métodos getter y setter
    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
        actualizarFechaModificacion();
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
        actualizarFechaModificacion();
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
        actualizarFechaModificacion();
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
        actualizarFechaModificacion();
    }

    public float getCalificacion() {
        return calificacion;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public Date getFechaModificacion() {
        return fechaModificacion;
    }

    public String getVersion() {
        return version;
    }

    public List<Actividad> getActividades() {
        return actividades;
    }

    // Actualizar la fecha de modificación
    private void actualizarFechaModificacion() {
        this.fechaModificacion = new Date();
    }

    // Agregar una actividad a la ruta
    public void agregarActividad(Actividad actividad) {
        actividades.add(actividad);
        System.out.println("Actividad añadida: " + actividad.getTitulo());
        actualizarFechaModificacion();
    }

    // Calcular el progreso de un estudiante en la ruta
    public float calcularProgreso(Estudiante estudiante) {
        int actividadesCompletadas = 0;
        for (Actividad actividad : actividades) {
            if (actividad.estaCompletadaPor(estudiante)) {
                actividadesCompletadas++;
            }
        }
        float progreso = (float) actividadesCompletadas / actividades.size() * 100;
        System.out.println("Progreso del estudiante: " + progreso + "%");
        return progreso;
    }

    // Verificar si un estudiante ha completado la ruta
    public boolean esCompletadaPorEstudiante(Estudiante estudiante) {
        for (Actividad actividad : actividades) {
            if (!actividad.estaCompletadaPor(estudiante)) {
                return false;
            }
        }
        return true;
    }

    // Obtener todas las actividades en la ruta
    public List<Actividad> obtenerActividades() {
        return actividades;
    }
}
