package learningpaths;

import java.util.ArrayList;
import java.util.List;

public class Profesor extends Usuario {
    private String especialidad;
    private List<RutaAprendizaje> rutasCreadas;

    // Constructor
    public Profesor(int id, String nombre, String correo, String contraseña, String especialidad) {
        super(id, nombre, correo, contraseña);
        this.especialidad = especialidad;
        this.rutasCreadas = new ArrayList<>();
    }

    // Métodos getter y setter
    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    // Crear una nueva ruta de aprendizaje
    public void crearRutaAprendizaje(RutaAprendizaje ruta) {
        rutasCreadas.add(ruta);
        System.out.println("Ruta de aprendizaje creada: " + ruta.getTitulo());
    }

    // Editar una ruta de aprendizaje existente
    public void editarRutaAprendizaje(RutaAprendizaje ruta, String nuevoTitulo, String nuevaDescripcion, String nuevoNivel, int nuevaDuracion) {
        ruta.setTitulo(nuevoTitulo);
        ruta.setDescripcion(nuevaDescripcion);
        ruta.setNivel(nuevoNivel);
        ruta.setDuracion(nuevaDuracion);
        System.out.println("Ruta de aprendizaje editada: " + ruta.getTitulo());
    }

    // Eliminar una ruta de aprendizaje
    public void eliminarRutaAprendizaje(RutaAprendizaje ruta) {
        rutasCreadas.remove(ruta);
        System.out.println("Ruta de aprendizaje eliminada: " + ruta.getTitulo());
    }

    // Ver reseñas de una actividad
    public List<Reseña> verReseñas(Actividad actividad) {
        return actividad.getReseñas(); // Supone que la clase Actividad tiene un método para obtener las reseñas
    }
}
