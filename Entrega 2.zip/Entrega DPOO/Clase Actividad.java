package learningpaths;

import java.util.Date;
import java.util.List;

public class Actividad {
    private int id;
    private String titulo;
    private String descripcion;
    private String tipo;
    private String nivel;
    private int duracion;
    private Date fechaLimite;
    private String estado; // e.g., "pendiente", "en progreso", "completada"
    private List<Actividad> prerrequisitos;
    private List<Actividad> actividadesSiguientes;

    // Constructor
    public Actividad(int id, String titulo, String descripcion, String tipo, String nivel, int duracion, Date fechaLimite) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.tipo = tipo;
        this.nivel = nivel;
        this.duracion = duracion;
        this.fechaLimite = fechaLimite;
        this.estado = "pendiente"; // Estado inicial
    }

    // Métodos getter y setter
    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getTipo() {
        return tipo;
    }

    public String getNivel() {
        return nivel;
    }

    public int getDuracion() {
        return duracion;
    }

    public Date getFechaLimite() {
        return fechaLimite;
    }

    public String getEstado() {
        return estado;
    }

    public List<Actividad> getPrerrequisitos() {
        return prerrequisitos;
    }

    public List<Actividad> getActividadesSiguientes() {
        return actividadesSiguientes;
    }

    // Verificar prerrequisitos
    public boolean verificarPrerrequisitos(Estudiante estudiante) {
        // Lógica para verificar si el estudiante ha completado todas las actividades prerrequisito
        for (Actividad actividad : prerrequisitos) {
            if (!actividad.estaCompletadaPor(estudiante)) {
                return false; // Si algún prerrequisito no está completado, retorna falso
            }
        }
        return true; // Todos los prerrequisitos cumplidos
    }

    // Completar actividad
    public void completar(Estudiante estudiante) {
        if (verificarPrerrequisitos(estudiante)) {
            this.estado = "completada";
            System.out.println("Actividad completada por el estudiante.");
        } else {
            System.out.println("Advertencia: No se han cumplido todos los prerrequisitos.");
            // El estudiante puede decidir si continuar o no (lógica en la clase Estudiante)
        }
    }

    // Método para saber si esta actividad está completada por un estudiante
    public boolean estaCompletadaPor(Estudiante estudiante) {
        // Lógica para determinar si la actividad está completada por el estudiante
        return this.estado.equals("completada");
    }
}
